<div class="modal fade" id="searchModal" name="searchModal" tabindex="-1">
        <div class="modal-dialog modal-medium">
            <div class="modal-content" style="background: rgba(9, 30, 62, .3);">
                <div class="modal-header border-0">
                    <button type="button" class="btn bg-white btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body d-flex align-items-center justify-content-center">
                    <div class="input-group" style="max-width: 600px;">
                        <?= $this->include('template/form') ?>
                    </div>
                </div>
            </div>
        </div>
    </div>